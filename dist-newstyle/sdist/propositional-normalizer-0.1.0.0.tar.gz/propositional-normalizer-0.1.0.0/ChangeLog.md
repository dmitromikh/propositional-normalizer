# Changelog for propositional-normalizer

## Unreleased changes
