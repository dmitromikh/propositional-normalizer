module Main where

import Prop

main :: IO ()
main = putStrLn "hello, world"
